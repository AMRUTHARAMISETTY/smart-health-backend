const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const app = express();
const PORT = 5000;
const DATA_PATH = path.join(__dirname, 'data.json');
const ML_URL = 'http://127.0.0.1:8000/predict'; // FastAPI endpoint

app.use(cors());
app.use(bodyParser.json());

// Ensure simple JSON DB exists
if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, JSON.stringify({ users: [] }, null, 2));
const readDB = () => JSON.parse(fs.readFileSync(DATA_PATH, 'utf-8'));
const writeDB = (db) => fs.writeFileSync(DATA_PATH, JSON.stringify(db, null, 2));

app.get('/', (_req, res) => res.send('Backend is running!'));

app.post('/signup', (req, res) => {
  const { name, age, email, password, vitals } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
  const db = readDB();
  if (db.users.find(u => u.email === email)) return res.status(409).json({ error: 'Email already exists' });
  db.users.push({ id: Date.now(), name, age, email, password, vitals: vitals || {} });
  writeDB(db);
  res.json({ ok: true });
});

app.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  const db = readDB();
  const user = db.users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ user: { id: user.id, name: user.name, email: user.email } });
});

// Simulated live vitals endpoint
app.get('/health-data', (_req, res) => {
  const payload = {
    time: new Date().toLocaleTimeString(),
    heartRate: Math.floor(Math.random() * (100 - 60) + 60),
    bloodPressure: Math.floor(Math.random() * (140 - 90) + 90),
    oxygen: Math.floor(Math.random() * (100 - 95) + 95)
  };
  res.json(payload);
});

// Proxy to ML microservice
app.post('/predict', async (req, res) => {
  try {
    const r = await fetch(ML_URL, { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify(req.body) });
    const data = await r.json();
    if (!r.ok) return res.status(500).json({ error: data.error || 'ML service error' });
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: 'Unable to reach ML service. Is it running on :8000?' });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));